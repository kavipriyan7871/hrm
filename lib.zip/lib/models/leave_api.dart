import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/api_client.dart';

class LeaveService {
  static final ApiClient _apiClient = ApiClient();

  /// ===============================
  /// GET EMPLOYEE TABLE ID
  /// ===============================
  static Future<String?> getEmployeeTableId() async {
    final prefs = await SharedPreferences.getInstance();
    // Prioritize login_cus_id, then uid (handling both string/int)
    String? id = prefs.getString('login_cus_id');
    if (id == null || id.isEmpty) {
      id = prefs.get('uid')?.toString();
    }
    return id;
  }

  /// ===============================
  /// GET LEAVE SUMMARY (Type: 2051)
  /// ===============================
  static Future<Map<String, dynamic>> getLeaveSummary() async {
    final prefs = await SharedPreferences.getInstance();
    final empId = await getEmployeeTableId();
    
    final body = {
      "type": "2051",
      "uid": empId ?? "",
      "id": empId ?? "",
      "token": prefs.getString('token') ?? "",
      "cid": (prefs.get('cid') ?? prefs.get('cid_str') ?? "").toString(),
      "device_id": prefs.getString('device_id') ?? "",
      "lt": (prefs.getDouble('lat') ?? 0.0).toString(),
      "ln": (prefs.getDouble('lng') ?? 0.0).toString(),
    };
    
    final res = await _apiClient.post(body);
    return jsonDecode(res.body);
  }

  /// ===============================
  /// GET LEAVE HISTORY (Type: 2052)
  /// ===============================
  static Future<Map<String, dynamic>> getLeaveHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final empId = await getEmployeeTableId();
    
    final body = {
      "type": "2052",
      "uid": empId ?? "",
      "id": empId ?? "",
      "token": prefs.getString('token') ?? "",
      "cid": (prefs.get('cid') ?? prefs.get('cid_str') ?? "").toString(),
      "device_id": prefs.getString('device_id') ?? "",
      "lt": (prefs.getDouble('lat') ?? 0.0).toString(),
      "ln": (prefs.getDouble('lng') ?? 0.0).toString(),
    };
    
    final res = await _apiClient.post(body);
    return jsonDecode(res.body);
  }

  /// ===============================
  /// GET LEAVE TYPES (Type: 2044)
  /// ===============================
  static Future<List<String>> getLeaveTypes() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final empId = await getEmployeeTableId();
      
      final body = {
        "type": "2044",
        "uid": empId ?? "",
        "id": empId ?? "",
        "token": prefs.getString('token') ?? "",
        "cid": (prefs.get('cid') ?? prefs.get('cid_str') ?? "").toString(),
        "device_id": prefs.getString('device_id') ?? "",
        "lt": (prefs.getDouble('lat') ?? 0.0).toString(),
        "ln": (prefs.getDouble('lng') ?? 0.0).toString(),
      };

      final res = await _apiClient.post(body);
      final data = jsonDecode(res.body);

      if (data["error"].toString() == "false") {
        var rawData = data["data"];
        List? rawList;
        if (rawData is List) {
           rawList = rawData;
        } else if (rawData is Map) {
           rawList = rawData["leave_types"] ?? rawData["data"] ?? rawData["list"];
        }
        
        rawList ??= data["leave_types"] ?? data["list"];

        if (rawList is List) {
          return rawList.map((e) {
            if (e is Map) {
              return (e["leave_type_name"] ?? e["leave_type"] ?? e["name"] ?? "").toString();
            }
            return e.toString();
          }).where((e) => e.isNotEmpty).toList();
        }
      }
    } catch (e) {
      debugPrint("API Error in getLeaveTypes: $e");
    }
    return [];
  }

  /// ===============================
  /// APPLY LEAVE (Type: 2043)
  /// ===============================
  static Future<Map<String, dynamic>> applyLeave({
    required String leaveType,
    required String fromDate,
    required String toDate,
    required String reason,
  }) async {
    final empId = await getEmployeeTableId();

    if (empId == null || empId.isEmpty) {
      return {
        "error": true,
        "error_msg": "Employee not found. Please re-login.",
      };
    }

    final prefs = await SharedPreferences.getInstance();
    final res = await _apiClient.post({
        "type": "2043",
        "uid": empId,
        "id": empId,
        "token": prefs.getString('token') ?? "",
        "leave_type": leaveType,
        "leave_start_date": fromDate,
        "leave_end_date": toDate,
        "reason": reason,
        "cid": prefs.getString('cid') ?? prefs.getString('cid_str') ?? "",
        "device_id": prefs.getString('device_id') ?? "",
        "lt": (prefs.getDouble('lat') ?? 0.0).toString(),
        "ln": (prefs.getDouble('lng') ?? 0.0).toString(),
    });

    return jsonDecode(res.body);
  }
}
