import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class PermissionApi {
  static const String baseUrl = "https://erpsmart.in/total/api/m_api/";

  static Future<String?> getEmployeeId() async {
    final prefs = await SharedPreferences.getInstance();
    // Use stabilized pattern for UID loading
    String? id = prefs.getString('login_cus_id');
    if (id == null || id.isEmpty) {
      id = prefs.get('uid')?.toString();
    }
    return id;
  }

  static Future<Map<String, String>> _getCommonParams() async {
    final prefs = await SharedPreferences.getInstance();
    return {
      "cid": (prefs.get('cid') ?? prefs.get('cid_str') ?? "").toString(),
      "device_id": prefs.getString('device_id') ?? "",
      "token": prefs.getString('token') ?? "",
      "lt": (prefs.getDouble('lat') ?? 0.0).toString(),
      "ln": (prefs.getDouble('lng') ?? 0.0).toString(),
    };
  }

  static Future<Map<String, dynamic>> submitPermission({
    required String permissionTypeId,
    required String date,
    required String fromTime,
    String? toTime,
    required String reason,
    required String deviceId,
    required String lt,
    required String ln,
  }) async {
    final common = await _getCommonParams();
    final String? empId = await getEmployeeId();

    final Map<String, String> body = {
      "type": "2065",
      "uid": empId ?? "",
      "id": empId ?? "",
      "permission_type_id": permissionTypeId,
      "permission_date": date,
      "from_time": fromTime,
      "end_time": toTime ?? "",
      "reason": reason,
      ...common,
      "device_id": deviceId, // Overwrite common if specific one passed
      "lt": lt,
      "ln": ln,
    };

    try {
      final response = await http.post(Uri.parse(baseUrl), body: body);
      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        return {"error": true, "error_msg": "Server error: ${response.statusCode}"};
      }
    } catch (e) {
      return {"error": true, "error_msg": e.toString()};
    }
  }

  static Future<Map<String, dynamic>> getPermissionTypes() async {
    final common = await _getCommonParams();
    final String? empId = await getEmployeeId();

    final Map<String, String> body = {
      "type": "2066",
      "uid": empId ?? "",
      "id": empId ?? "",
      ...common,
    };

    try {
      final response = await http.post(Uri.parse(baseUrl), body: body);
      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        return {"error": true, "error_msg": "Server error: ${response.statusCode}"};
      }
    } catch (e) {
      return {"error": true, "error_msg": e.toString()};
    }
  }

  static Future<Map<String, dynamic>> getPermissionHistory() async {
    final common = await _getCommonParams();
    final String? empId = await getEmployeeId();

    final Map<String, String> body = {
      "type": "2078",
      "uid": empId ?? "",
      "id": empId ?? "",
      ...common,
    };

    try {
      final response = await http.post(Uri.parse(baseUrl), body: body);
      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        return {"error": true, "error_msg": "Server error: ${response.statusCode}"};
      }
    } catch (e) {
      return {"error": true, "error_msg": e.toString()};
    }
  }
}
